/** @file
Copyright (C) 2017, Download-Fritz.  All rights reserved.<BR>
This program and the accompanying materials are licensed and made available
under the terms and conditions of the BSD License which accompanies this
distribution.  The full text of the license may be found at
http://opensource.org/licenses/bsd-license.php.

THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.

**/

#ifndef APPLE_CPU_EXTENSIONS_LIB_H
#define APPLE_CPU_EXTENSIONS_LIB_H

// AppleEnableCpuExtensions
VOID
AppleEnableCpuExtensions (
  VOID
  );

#endif // APPLE_CPU_EXTENSIONS_LIB_H
